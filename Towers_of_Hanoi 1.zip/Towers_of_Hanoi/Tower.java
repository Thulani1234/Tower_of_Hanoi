package tower.hanoi.game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.util.Stack;

public class Tower extends JPanel implements MouseListener, MouseMotionListener {

    private static final long serialVersionUID = 0xffL;

    private Stack<Rectangle2D.Double>[] s = new Stack[3];
    private Stack<Color>[] disk_color = new Stack[3];
    private static Rectangle2D.Double top = null;
    private Color top_color = null;
    private double ax, ay, w, h;
    private boolean draggable = false, firstTime = false;

    public Tower() {
        firstTime = true;
        init(4); // Initialize with 4 disks
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void init(int val) {
        Color[] c = {Color.yellow, Color.blue, Color.green, Color.red, Color.pink,
                     Color.orange, Color.black, Color.cyan, Color.gray, Color.white};
        s[0] = new Stack<>();
        s[1] = new Stack<>();
        s[2] = new Stack<>();

        disk_color[0] = new Stack<>();
        disk_color[1] = new Stack<>();
        disk_color[2] = new Stack<>();

        for (int i = 0; i < val; i++) {
            Rectangle2D.Double r = new Rectangle2D.Double();
            double x = getWidth() / 6;
            x = (x == 0) ? 109 : x;
            double wr = val * 25 - 20 * i;
            r.setFrame(x - wr / 2, 300 - i * 20, wr, 20); // adjusted y-axis
            s[0].push(r);
            disk_color[0].push(c[i]);
        }
        top = null;
        top_color = null;
        ax = 0.0;
        ay = 0.0;
        w = 0.0;
        h = 0.0;
        draggable = false;
        repaint();
    }

    private int current_tower(Point pos) {
        int x = pos.x;
        int width = getWidth();
        if (x < width / 3) return 0;
        else if (x < 2 * width / 3) return 1;
        else return 2;
    }

    @Override
    public void mouseClicked(MouseEvent ev) {}

    @Override
    public void mousePressed(MouseEvent ev) {
        Point pos = ev.getPoint();
        int n = current_tower(pos);
        if (!s[n].isEmpty()) {
            top = s[n].pop();
            top_color = disk_color[n].pop();
            ax = top.getX();
            ay = top.getY();
            w = pos.getX() - ax;
            h = pos.getY() - ay;
            draggable = true;
        } else {
            top = null;
            top_color = Color.black;
            draggable = false;
        }
    }

    @Override
    public void mouseReleased(MouseEvent ev) {
        if (top != null && draggable) {
            int tower = current_tower(ev.getPoint());
            double x, y;

            if (!s[tower].isEmpty()) {
                if (s[tower].peek().getWidth() > top.getWidth())
                    y = s[tower].peek().getY() - 20;
                else {
                    JOptionPane.showMessageDialog(this, "Wrong Move", "Tower of Hanoi", JOptionPane.ERROR_MESSAGE);
                    repaint();
                    return;
                }
            } else {
                y = getHeight() - 40;
            }

            x = (getWidth() / 6) + (getWidth() / 3) * tower - top.getWidth() / 2;
            top.setFrame(x, y, top.getWidth(), top.getHeight());
            s[tower].push(top);
            disk_color[tower].push(top_color);
            top = null;
            top_color = Color.black;
            draggable = false;
            repaint();
        }
    }

    @Override
    public void mouseEntered(MouseEvent ev) {}

    @Override
    public void mouseExited(MouseEvent ev) {}

    @Override
    public void mouseMoved(MouseEvent ev) {}

    @Override
    public void mouseDragged(MouseEvent ev) {
        int cx = ev.getX();
        int cy = ev.getY();
        if (top != null && draggable) {
            top.setFrame(cx - w, cy - h, top.getWidth(), top.getHeight());
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // always call super.paintComponent
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.black);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        int holder_x = getWidth() / 6;
        int holder_y1 = getHeight() - 10 * 20;
        int holder_y2 = getHeight() - 20;

        g2d.setColor(Color.white);
        g2d.setStroke(new BasicStroke(5));
        for (int i = 0; i < 3; i++) {
            int base_x = holder_x + i * getWidth() / 3;
            g2d.drawLine(base_x, holder_y1, base_x, holder_y2);
        }

        // Draw disks
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < s[i].size(); j++) {
                Rectangle2D.Double r = s[i].get(j);
                g2d.setColor(disk_color[i].get(j));
                g2d.fill(r);
            }
        }

        if (top != null) {
            g2d.setColor(top_color);
            g2d.fill(top);
        }
    }
}
