package tower.hanoi.game;

import java.util.Scanner;

public class Tower_of_hanoi {
    
    public void solveTowersOfHanoi(int n, String source, String aux, String dest) {
        if (n == 1) {
            System.out.println(source + " --> " + dest);
            return;
        }
        solveTowersOfHanoi(n - 1, source, dest, aux);
        System.out.println(source + " --> " + dest);
        solveTowersOfHanoi(n - 1, aux, source, dest);
    }

    public static void main(String[] args) {
        Tower_of_hanoi obj = new Tower_of_hanoi(); // 🔥 Fix: use the correct class name
        System.out.println("Enter the number of disks: ");
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.close();
        
        System.out.println("Move disks as below illustration:");
        obj.solveTowersOfHanoi(n, "A", "B", "C");
    }
}
