package tower.hanoi.game;

import java.sql.*;
import java.time.Duration;
import java.time.Instant;

public class Database {
    private static final String DB_URL = "jdbc:sqlite:hanoi_records.db";
    
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
    
    public static void initialize() {
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            
            stmt.execute("CREATE TABLE IF NOT EXISTS records (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                         "player_name TEXT NOT NULL," +
                         "disks INTEGER NOT NULL," +
                         "moves INTEGER NOT NULL," +
                         "algorithm TEXT NOT NULL," +
                         "time_taken_ms INTEGER NOT NULL," +
                         "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");
            
            stmt.execute("CREATE TABLE IF NOT EXISTS algorithm_stats (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                         "algorithm TEXT NOT NULL," +
                         "disks INTEGER NOT NULL," +
                         "time_taken_ms INTEGER NOT NULL," +
                         "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)");
        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
        }
    }
    
    public static void saveRecord(String playerName, int disks, int moves, 
                                 String algorithm, long timeTaken) {
        String sql = "INSERT INTO records(player_name, disks, moves, algorithm, time_taken_ms) " +
                     "VALUES(?,?,?,?,?)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, playerName);
            pstmt.setInt(2, disks);
            pstmt.setInt(3, moves);
            pstmt.setString(4, algorithm);
            pstmt.setLong(5, timeTaken);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error saving record: " + e.getMessage());
        }
    }
    
    public static void saveAlgorithmStats(String algorithm, int disks, long timeTaken) {
        String sql = "INSERT INTO algorithm_stats(algorithm, disks, time_taken_ms) " +
                     "VALUES(?,?,?)";
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, algorithm);
            pstmt.setInt(2, disks);
            pstmt.setLong(3, timeTaken);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error saving algorithm stats: " + e.getMessage());
        }
    }
}