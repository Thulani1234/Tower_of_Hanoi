package tower.hanoi.game;

import java.awt.event.*;
import javax.swing.*;
import java.util.List;
import java.util.ArrayList;
import java.time.Instant;
import java.time.Duration;

public class Run_Game implements ActionListener {
    private static JFrame f = new JFrame();
    private static Tower t;
    private static JMenuBar menu_bar = new JMenuBar();
    
    private JMenuItem
        new_game = new JMenuItem("New Game"),
        best_time = new JMenuItem("Best Time"),
        exit = new JMenuItem("Exit"),
        about = new JMenuItem("About..."),
        recursive_solver = new JMenuItem("Recursive Solver"),
        iterative_solver = new JMenuItem("Iterative Solver"),
        compare_algorithms = new JMenuItem("Compare Algorithms"),
        enter_moves = new JMenuItem("Enter Moves");
    
    private JMenu
        help = new JMenu("Help"),
        game = new JMenu("Game"),
        algorithms = new JMenu("Algorithms"),
        play = new JMenu("Play");
    
    public Run_Game(String title) {
        f.setTitle(title);
        build();
    }
    
    public void actionPerformed(ActionEvent ev) {
        if (ev.getSource() == new_game) {
            t.initializeGame();
        } else if (ev.getSource() == recursive_solver) {
            t.solve(t.disks, 'A', 'C', 'B');
        } else if (ev.getSource() == iterative_solver) {
            t.solveIterative(t.disks, 'A', 'B', 'C');
        } else if (ev.getSource() == compare_algorithms) {
            new Thread(() -> {
                FrameStewart4Pegs.compareSolutions(t.disks);
            }).start();
        } else if (ev.getSource() == enter_moves) {
            promptForMoves();
        } else if (ev.getSource() == exit) {
            System.exit(0);
        } else if (ev.getSource() == about) {
            showAboutDialog();
        } else if (ev.getSource() == best_time) {
            showBestTimes();
        }
    }
    
    private void promptForMoves() {
        if (t == null || t.disks == 0) {
            JOptionPane.showMessageDialog(f, 
                "Please start a new game first!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Ask for number of moves
        String movesInput = JOptionPane.showInputDialog(f, 
            "Enter the number of moves you think are needed to solve " + t.disks + " disks:",
            "Number of Moves", 
            JOptionPane.QUESTION_MESSAGE);
        
        if (movesInput == null || movesInput.trim().isEmpty()) {
            return; // User cancelled
        }
        
        try {
            int expectedMoves = Integer.parseInt(movesInput.trim());
            int optimalMoves = (int) (Math.pow(2, t.disks) - 1);
            
            if (expectedMoves < optimalMoves) {
                JOptionPane.showMessageDialog(f, 
                    "Impossible! The minimum number of moves for " + t.disks + 
                    " disks is " + optimalMoves, 
                    "Invalid Move Count", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Ask for sequence of moves
            String movesSequence = JOptionPane.showInputDialog(f, 
                "Enter your sequence of moves (e.g., AB, AC, BC):\n" +
                "Format: source peg (A/B/C) + destination peg (A/B/C) separated by commas",
                "Move Sequence", 
                JOptionPane.PLAIN_MESSAGE);
                
            if (movesSequence == null || movesSequence.trim().isEmpty()) {
                return; // User cancelled
            }
                
            // Validate and execute moves
            validateAndExecuteMoves(movesSequence.trim().toUpperCase(), optimalMoves);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(f, 
                "Please enter a valid number!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void validateAndExecuteMoves(String movesSequence, int optimalMoves) {
        String[] moves = movesSequence.split("\\s*,\\s*");
        List<String> validMoves = new ArrayList<>();
        
        // Basic validation
        for (String move : moves) {
            move = move.trim();
            if (move.length() != 2 || 
                !"ABC".contains(move.substring(0, 1)) || 
                !"ABC".contains(move.substring(1, 2))) {
                JOptionPane.showMessageDialog(f, 
                    "Invalid move format: " + move + "\n" +
                    "Each move should be two letters (e.g., AB, AC, BC)\n" +
                    "where first letter is source peg and second is destination peg",
                    "Invalid Move", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            validMoves.add(move);
        }
        
        // Execute moves
        try {
            t.resetGame(); // Reset to initial state
            
            Instant start = Instant.now();
            boolean success = t.executeMoveSequence(validMoves);
            Duration duration = Duration.between(start, Instant.now());
            
            if (success) {
                Database.saveRecord(t.playerName, t.disks, validMoves.size(), 
                                  "User Input", duration.toMillis());
                
                String message = "Congratulations! You solved the puzzle in " + 
                               validMoves.size() + " moves.\n" +
                               "Time taken: " + duration.toMillis() + " ms\n";
                               
                if (validMoves.size() == optimalMoves) {
                    message += "\nPerfect! You used the minimum number of moves!";
                } else {
                    message += "\nThe minimum number of moves is " + optimalMoves + 
                              ". Can you do better?";
                }
                
                JOptionPane.showMessageDialog(f, 
                    message, 
                    "Success!", 
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(f, 
                    "Your sequence didn't solve the puzzle. Try again!", 
                    "Incomplete Solution", 
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (IllegalMoveException e) {
            JOptionPane.showMessageDialog(f, 
                "Invalid move at step " + (e.getMoveIndex() + 1) + ": " + e.getMessage() +
                "\n\nMove was: " + moves[e.getMoveIndex()] +
                "\n\nGame has been reset to initial state.",
                "Invalid Move", 
                JOptionPane.ERROR_MESSAGE);
            t.resetGame();
        }
    }
    
    private void showBestTimes() {
        try {
            List<String> records = Database.getTopRecords(5);
            if (records.isEmpty()) {
                JOptionPane.showMessageDialog(f, 
                    "No records found in the database.", 
                    "Best Times", 
                    JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            StringBuilder message = new StringBuilder("Top Scores:\n");
            for (String record : records) {
                message.append(record).append("\n");
            }
            
            JOptionPane.showMessageDialog(f, 
                message.toString(), 
                "Best Times", 
                JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(f, 
                "Error retrieving records: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void showAboutDialog() {
        JOptionPane.showMessageDialog(f, 
            "Tower of Hanoi Game\nVersion 2.0\n\n" +
            "Rules:\n" +
            "1. Only one disk can be moved at a time.\n" +
            "2. A larger disk cannot be placed on a smaller disk.\n" +
            "3. You can use the auxiliary peg to help move the disks.\n\n" +
            "How to play:\n" +
            "- Use 'New Game' to start\n" +
            "- Use 'Enter Moves' to input your solution\n" +
            "- Watch the recursive or iterative solvers for help",
            "About Tower of Hanoi", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void build() {
        game.add(new_game);
        game.add(best_time);
        game.add(exit);
        
        algorithms.add(recursive_solver);
        algorithms.add(iterative_solver);
        algorithms.add(compare_algorithms);
        
        play.add(enter_moves);
        
        help.add(about);
        
        menu_bar.add(game);
        menu_bar.add(algorithms);
        menu_bar.add(play);
        menu_bar.add(help);
        
        new_game.addActionListener(this);
        recursive_solver.addActionListener(this);
        iterative_solver.addActionListener(this);
        compare_algorithms.addActionListener(this);
        enter_moves.addActionListener(this);
        exit.addActionListener(this);
        about.addActionListener(this);
        best_time.addActionListener(this);
        
        f.setJMenuBar(menu_bar);
        f.setExtendedState(JFrame.MAXIMIZED_BOTH);
        f.setResizable(true);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) {
        Database.initialize();
        SwingUtilities.invokeLater(() -> {
            Run_Game obj = new Run_Game("Tower of Hanoi v2.0");
            t = new Tower();
            f.getContentPane().add(t);
        });
    }
}