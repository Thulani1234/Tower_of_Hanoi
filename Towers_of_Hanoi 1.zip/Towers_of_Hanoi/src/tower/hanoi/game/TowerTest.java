package tower.hanoi.game;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import javax.swing.JTextArea;
import java.sql.Connection;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class TowerTest {
    
    // Main method to run tests
    public static void main(String[] args) {
        org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder.request()
            .selectors(org.junit.platform.engine.discovery.DiscoverySelectors.selectClass(TowerTest.class))
            .build();
        
        org.junit.platform.launcher.core.LauncherFactory.create()
            .execute(new org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder()
                .selectors(org.junit.platform.engine.discovery.DiscoverySelectors.selectClass(TowerTest.class))
                .build());
    }

    @Test
    public void testDatabaseConnection() {
        assertDoesNotThrow(() -> {
            Connection conn = Database.connect();
            assertNotNull(conn);
            if (conn != null) conn.close();
        });
    }
    
    @Test
    public void testFrameStewartAlgorithmSmallCase() {
        JTextArea dummyArea = new JTextArea();
        int[] moves = {0};
        assertDoesNotThrow(() -> 
            FrameStewart4Pegs.solveFrameStewart(3, "A", "D", "B", "C", dummyArea, moves));
        assertTrue(moves[0] > 0);
    }
    
    @Test
    public void testInvalidDiskNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new TowerOfHanoi(0);
        });
        assertEquals("Number of disks must be greater than 0", exception.getMessage());
    }
    
    @Test
    public void testStandardHanoiAlgorithm() {
        JTextArea dummyArea = new JTextArea();
        int[] moves = {0};
        assertDoesNotThrow(() -> 
            FrameStewart4Pegs.solveStandardHanoi(3, "A", "C", "B", dummyArea, moves));
        assertEquals(7, moves[0]); // 3 disks should take 7 moves
    }
    
    @Test
    public void testWinCondition() throws InterruptedException {
        Tower tower = new Tower();
        tower.init(3);
        
        // Use CountDownLatch to wait for async completion
        CountDownLatch latch = new CountDownLatch(1);
        
        new Thread(() -> {
            tower.solve(3, 'A', 'C', 'B');
            latch.countDown();
        }).start();
        
        // Wait for completion with timeout
        assertTrue(latch.await(5, TimeUnit.SECONDS), "Solver didn't complete in time");
        assertTrue(tower.checkWinCondition());
    }
    
   