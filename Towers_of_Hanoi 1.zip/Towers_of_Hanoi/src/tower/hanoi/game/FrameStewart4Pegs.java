package tower.hanoi.game;

import javax.swing.JTextArea;
import java.util.Scanner;
import java.time.Instant;
import java.time.Duration;

public class FrameStewart4Pegs {
    private int disks;
    
    public FrameStewart4Pegs(int disks) {
        if (disks < 1) {
            throw new IllegalArgumentException("Number of disks must be greater than 0");
        }
        this.disks = disks;
    }
    
    public static void main(String[] args) {
        Database.initialize();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter number of disks (5-10):");
        int n;
        try {
            n = scanner.nextInt();
            if (n < 5 || n > 10) {
                throw new IllegalArgumentException("Number of disks must be between 5 and 10");
            }
        } catch (Exception e) {
            System.err.println("Invalid input: " + e.getMessage());
            scanner.close();
            return;
        }
        
        FrameStewart4Pegs solver = new FrameStewart4Pegs(n);
        solver.compareSolutions();
        
        scanner.close();
    }
    
    public void compareSolutions() {
        // Solve using Frame-Stewart (4 pegs)
        JTextArea area4Pegs = new JTextArea();
        int[] moves4Pegs = {0};
        Instant start4Pegs = Instant.now();
        solveFrameStewart(disks, "A", "D", "B", "C", area4Pegs, moves4Pegs);
        Duration duration4Pegs = Duration.between(start4Pegs, Instant.now());
        
        System.out.println("\n--- Frame-Stewart Solution (4 Pegs) ---");
        System.out.println(area4Pegs.getText());
        System.out.println("Total moves (4 pegs): " + moves4Pegs[0]);
        System.out.println("Time taken: " + duration4Pegs.toMillis() + " ms");
        
        // Solve using classic 3-peg Tower of Hanoi
        JTextArea area3Pegs = new JTextArea();
        int[] moves3Pegs = {0};
        Instant start3Pegs = Instant.now();
        solveStandardHanoi(disks, "A", "C", "B", area3Pegs, moves3Pegs);
        Duration duration3Pegs = Duration.between(start3Pegs, Instant.now());
        
        System.out.println("\n--- Classic Tower of Hanoi Solution (3 Pegs) ---");
        System.out.println(area3Pegs.getText());
        System.out.println("Total moves (3 pegs): " + moves3Pegs[0]);
        System.out.println("Time taken: " + duration3Pegs.toMillis() + " ms");
        
        // Save algorithm stats
        Database.saveAlgorithmStats("Frame-Stewart (4 pegs)", disks, duration4Pegs.toMillis());
        Database.saveAlgorithmStats("Classic (3 pegs)", disks, duration3Pegs.toMillis());
        
        // Compare
        System.out.println("\n--- Comparison ---");
        if (moves4Pegs[0] < moves3Pegs[0]) {
            System.out.println("Frame-Stewart (4 pegs) is faster with fewer moves!");
        } else if (moves4Pegs[0] > moves3Pegs[0]) {
            System.out.println("Classic 3-peg Hanoi is faster (unexpected).");
        } else {
            System.out.println("Both methods took the same number of moves.");
        }
        
        System.out.println("Time difference: " + 
            (duration3Pegs.toMillis() - duration4Pegs.toMillis()) + " ms");
    }
    
    public static void solveFrameStewart(int n, String source, String destination, 
                                       String auxiliary1, String auxiliary2, 
                                       JTextArea displayArea, int[] moveCounter) {
        if (n == 0) return;
        
        if (n == 1) {
            displayArea.append("Move disk 1 from " + source + " to " + destination + "\n");
            moveCounter[0]++;
            return;
        }
        
        int k = n - (int) Math.round(Math.sqrt(2 * n + 1)) + 1;
        
        solveFrameStewart(k, source, auxiliary1, auxiliary2, destination, displayArea, moveCounter);
        solveStandardHanoi(n - k, source, destination, auxiliary2, displayArea, moveCounter);
        solveFrameStewart(k, auxiliary1, destination, source, auxiliary2, displayArea, moveCounter);
    }
    
    private static void solveStandardHanoi(int n, String source, String destination, 
                                         String auxiliary, JTextArea displayArea, 
                                         int[] moveCounter) {
        if (n == 0) return;
        
        solveStandardHanoi(n - 1, source, auxiliary, destination, displayArea, moveCounter);
        displayArea.append("Move disk " + n + " from " + source + " to " + destination + "\n");
        moveCounter[0]++;
        solveStandardHanoi(n - 1, auxiliary, destination, source, displayArea, moveCounter);
    }
}