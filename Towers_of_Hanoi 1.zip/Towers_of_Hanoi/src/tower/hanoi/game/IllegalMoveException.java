/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tower.hanoi.game;

/**
 *
 * @author PC
 */
public class IllegalMoveException extends Exception {

    public IllegalMoveException(String invalid_move, int i) {
    }
    
}
