package tower.hanoi.game;

import java.util.Scanner;
import java.util.Stack;
import java.time.Instant;
import java.time.Duration;

public class Tower_of_hanoi {
    private int disks;
    
    public Tower_of_hanoi(int disks) {
        if (disks < 1) {
            throw new IllegalArgumentException("Number of disks must be greater than 0");
        }
        this.disks = disks;
    }
    
    // Recursive solution with timing
    public void solveRecursive(int n, String fromRod, String auxRod, String toRod) {
        Instant start = Instant.now();
        recursiveMove(n, fromRod, auxRod, toRod);
        Duration duration = Duration.between(start, Instant.now());
        Database.saveAlgorithmStats("Recursive", n, duration.toMillis());
    }
    
    private void recursiveMove(int n, String fromRod, String auxRod, String toRod) {
        if (n == 1) {
            System.out.println("Move disk 1 from " + fromRod + " to " + toRod);
            return;
        }
        recursiveMove(n - 1, fromRod, toRod, auxRod);
        System.out.println("Move disk " + n + " from " + fromRod + " to " + toRod);
        recursiveMove(n - 1, auxRod, fromRod, toRod);
    }
    
    // Iterative solution with timing
    public void solveIterative(int num_of_disks, char fromRod, char auxRod, char toRod) {
        Instant start = Instant.now();
        iterativeMove(num_of_disks, fromRod, auxRod, toRod);
        Duration duration = Duration.between(start, Instant.now());
        Database.saveAlgorithmStats("Iterative", num_of_disks, duration.toMillis());
    }
    
    private void iterativeMove(int num_of_disks, char fromRod, char auxRod, char toRod) {
        Stack<Integer> src = new Stack<>();
        Stack<Integer> aux = new Stack<>();
        Stack<Integer> dest = new Stack<>();
        
        for (int i = num_of_disks; i >= 1; i--) {
            src.push(i);
        }
        
        int totalMoves = (int) (Math.pow(2, num_of_disks) - 1);
        
        for (int i = 1; i <= totalMoves; i++) {
            if (i % 3 == 1) {
                moveDiskBetweenPoles(src, dest, fromRod, toRod);
            } else if (i % 3 == 2) {
                moveDiskBetweenPoles(src, aux, fromRod, auxRod);
            } else if (i % 3 == 0) {
                moveDiskBetweenPoles(aux, dest, auxRod, toRod);
            }
        }
    }
    
    private void moveDiskBetweenPoles(Stack<Integer> src, Stack<Integer> dest, char s, char d) {
        int pole1TopDisk = src.isEmpty() ? Integer.MAX_VALUE : src.pop();
        int pole2TopDisk = dest.isEmpty() ? Integer.MAX_VALUE : dest.pop();
        
        if (pole1TopDisk > pole2TopDisk) {
            src.push(pole1TopDisk);
            src.push(pole2TopDisk);
            System.out.println("Move disk " + pole2TopDisk + " from " + d + " to " + s);
        } else {
            dest.push(pole2TopDisk);
            dest.push(pole1TopDisk);
            System.out.println("Move disk " + pole1TopDisk + " from " + s + " to " + d);
        }
    }
    
    public static void main(String[] args) {
        Database.initialize();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Welcome to Tower of Hanoi Solver!");
        System.out.print("Enter number of disks (5-10): ");
        int numDisks;
        try {
            numDisks = scanner.nextInt();
            if (numDisks < 5 || numDisks > 10) {
                throw new IllegalArgumentException("Number of disks must be between 5 and 10");
            }
        } catch (Exception e) {
            System.err.println("Invalid input: " + e.getMessage());
            scanner.close();
            return;
        }
        
        System.out.println("Choose method: ");
        System.out.println("1. Recursive Solution");
        System.out.println("2. Iterative Solution");
        System.out.print("Enter your choice (1 or 2): ");
        
        int choice;
        try {
            choice = scanner.nextInt();
            if (choice != 1 && choice != 2) {
                throw new IllegalArgumentException("Choice must be 1 or 2");
            }
        } catch (Exception e) {
            System.err.println("Invalid choice: " + e.getMessage());
            scanner.close();
            return;
        }
        
        Tower_of_hanoi hanoi = new Tower_of_hanoi(numDisks);
        
        if (choice == 1) {
            System.out.println("\nSolving recursively:");
            hanoi.solveRecursive(numDisks, "A", "B", "C");
        } else {
            System.out.println("\nSolving iteratively:");
            hanoi.solveIterative(numDisks, 'A', 'B', 'C');
        }
        
        scanner.close();
    }
}